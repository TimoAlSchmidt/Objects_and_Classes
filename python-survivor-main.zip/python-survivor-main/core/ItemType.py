from enum import Enum
class ItemType(Enum):
  HEALTHPACK = 'healthpack'
  WEAPON = 'weapon'
  ARMOR = 'armor'
  