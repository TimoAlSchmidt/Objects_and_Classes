import core

class IdleCommand(core.Command):
  pass

