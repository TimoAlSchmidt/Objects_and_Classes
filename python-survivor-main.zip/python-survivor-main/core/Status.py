import core

class Status:
  pass